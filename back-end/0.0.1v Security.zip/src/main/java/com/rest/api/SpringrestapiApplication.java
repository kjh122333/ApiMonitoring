package com.rest.api;

// Default import
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
// Bean import
import org.springframework.context.annotation.Bean;
// Password Encoder
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class SpringrestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringrestapiApplication.class, args);
	}

	/**
	 * NOTE 
	 * ### PasswordEncoder ###
	 * - Spring Security
	 * - Interface
	 * - password를 단반향으로 변환해서, 안전하게 저장하게 해줌
	 * - 편도 방향( 양방향일 경우 제공 안함 )
	 * - 유저의 비밀번호와 비교할 암호를 저장하는데 사용
	 * - 구글링 해보니 단방향으로 변환된 암호를 풀어서 다시 암호화하는 것은 난이도가 높은 방법( 해결책 : `DelegatingPasswordEncoder` )
	 */
	@Bean // BEAN 등록 : PasswordEncoder
	public PasswordEncoder passwordEncoder() {
		/**
		 * NOTE 
		 * ### PasswordEncoderFactories.createDelegatingPasswordEncoder() ###
		 * - 해당 메소드로 생성된 password는 `BCryptPasswordEncoder`가 사용함
		 * - {id} 로 PasswordEncoder형식(타입)이 정해짐
		 */
		return PasswordEncoderFactories.createDelegatingPasswordEncoder();
	}
}
