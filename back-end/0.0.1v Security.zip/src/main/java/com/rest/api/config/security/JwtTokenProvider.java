package com.rest.api.config.security;

import java.util.Base64;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.RequiredArgsConstructor;

/**
 * JwtTokenProvider : JWT Token 생성, 검증
 * 
 * NOTE 
 * ### @RequiredArgsConstructor ###
 * - 생성자 자동으로 생성 어노테이션
 * - [관련] @NoArgsConstructor : 파라미터가 없는 기본 생성자를 생성,
 * - [관련] @AllArgsConstructor : 모든 필드 값을 파라미터로 받는 생성자를 만들줌
 * - [관련] @RequiredArgsConstructor : final이나 @NonNull인 필드 값만 파라미터로 받는 생성자 만들어줌
 * 
 * NOTE
 * ### [INTERFACE] UserDetailsService ###
 * - 사용자 정보 검색 관련
 * - loadUserByUsername() 메소드로 DB에서 유저에 대한 정보를 로드함

 * NOTE
 * ### @PostConstruct ###
 * - 의존성 주입 이후에  초기화를 수행하는 메소드
 * - 초기화할 메서드에는 파라미터 X ( 파라미터가 존재한다면 에러 )
 * - return 타입이 있는 메서드를 작성해도 되지만 사용되지 않음
 * 
 * NOTE
 * ### Base64 ###
 * - 8비트 이진 데이터(예를 들어 실행 파일이나, ZIP 파일 등)를 문자 코드에 영향을 받지 않는 공통 ASCII 영역의 문자들로만 이루어진 일련의 문자열로 바꾸는 인코딩 방식
 * 
 * NOTE
 * ### Claims ###
 * - 주장
 * - 사용자의 프로퍼티, 속성
 * - JWT는 JSON를 이용해 claims을 정의
 * 
 * NOTE
 *  ### [final CLASS] Jwts ###
 * - claims() : 모든 claims을 한번에 세팅
 * - setSubject() : `sub` 세팅
 * - builder()  : 토큰 생성시 첫부분으로 사용
 * - setClaims(claims) : 호출시 이미 설정된 동일 이름으로 기존 claim에 덮어 씀
 * - setIssuedAt(now)  : 토큰 실행 시점 세팅
 * - setExpiration() : 토큰 인증 종료 시점 세팅
 * - signWith(알고리즘, 키) : 기본 알고리즘이 있지만, 쩃든 키값에 대해 알고리즘으로 변환
 * - SignatureAlgorithm.HS256
 * - compact() : 상위 세팅 메소드를 통해 마지막으로 압축 메소드
 * - parser() : jwt 인스턴스 호출시
 * - parseClaimsJws() : 원래의 string 값 생성
 * - getBody() : Body값 리턴
 * - getSubject() : Subject 값  리턴
 * - before(시간) : 해당 시간 이후로는 토큰 처리를 않시키겠다
 * 
 * NOTE
 * ### HttpServletRequest ###
 * NOTE
 * ### HttpServletRequest.getHeader() ###
 * NOTE
 * ### X-AUTH-TOKEN ###
 */
@RequiredArgsConstructor
@Component
public class JwtTokenProvider {

    @Value("spring.jwt.secret")
    private String secretKey;

    // token's life per 1 hour
    private long tokenValidTime = 1000L * 60 * 60;
    
    private final UserDetailsService userDetailsService;

    @PostConstruct
    protected void init(){
        secretKey = Base64.getUrlEncoder().encodeToString(secretKey.getBytes());
    }

    // Create Json Web Token
    public String createToken(String userPrimaryKey, List<String> roles) {

        Claims claims = Jwts.claims().setSubject(userPrimaryKey);
        claims.put("roles", roles);
        Date now = new Date();

        return Jwts.builder()
                .setClaims(claims) // data
                .setIssuedAt(now) // create data of token
                .setExpiration(new Date(now.getTime() + tokenValidTime)) // set dead time
                .signWith(SignatureAlgorithm.HS256, secretKey) // set "encoding algorithm", "secret value"
                .compact();
    }

    /**
     * 
     * NOTE
     * ### Authentication ###
     * - 해당 사용자가 본인이 맞는지를 확인하는 절차
     * - 파라미터(token)를 통해
     * NOTE
     * ### UserDetails ###
     * - 계정에 대한 vo라고 생각하면됨
     * NOTE
     * ### UsernamePasswordAuthenticationToken(vo, null, list) ###
     * - 시큐리티에서 제공되는 클래스
     * - 해당 값들로 저장해서 반환하는 데 사용
     * NOTE
     * ### userDetails.getAuthorities() ###
     * - 사용자 계정들의 권한 목록 리스트를 반환
     */
    // 인증 정보를 조회
    // import org.springframework.security.core.Authentication;
    public Authentication getAuthentication(String token) {
        UserDetails userDetails = userDetailsService.loadUserByUsername(this.getUserPrimaryKey(token));
        return new UsernamePasswordAuthenticationToken(userDetails, "", userDetails.getAuthorities());
    }

    // 회원 구분 정보를 추출 
    public String getUserPrimaryKey(String token) {
        return Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token).getBody().getSubject();
    }

    // 요청 값에 대한 해더에서 token 파싱
    public String resolveToken(HttpServletRequest req) {
        return req.getHeader("X-AUTH-TOKEN");
    }

    // 토큰의 유효성 체크 
    // 만료일자 체크
    public boolean validateToken(String jwtToken) {
        try {
            Jws<Claims> claims = Jwts.parser().setSigningKey(secretKey).parseClaimsJws(jwtToken);
            return !claims.getBody().getExpiration().before(new Date());
        } catch (Exception e) {
            return false;
        }
    }


}