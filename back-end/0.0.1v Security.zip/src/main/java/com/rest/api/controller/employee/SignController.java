package com.rest.api.controller.employee;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Date;

import com.rest.api.advice.exception.CEmailSigninFailedException;
import com.rest.api.config.security.JwtTokenProvider;
import com.rest.api.entity.Employee;
import com.rest.api.model.response.result.Common;
import com.rest.api.model.response.result._Single;
import com.rest.api.repo.EmployeeJpaRepository;
import com.rest.api.service.ResponseService;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

/**
 * SignController
 */
@Api(tags = { "1. Sign" }) // swagger output 세팅
@RequiredArgsConstructor
@RestController
@RequestMapping(value = "/employee")
public class SignController {

    private final EmployeeJpaRepository employeeJpaRepository;
    private final JwtTokenProvider jwtTokenProvider;
    private final ResponseService responseService;
    private final PasswordEncoder passwordEncoder;

    @ApiOperation(value = "로그인", notes = "아이디 회원 로그인을 한다.")
    @PostMapping(value = "/signin")
    public _Single<String> signin(@ApiParam(value = "회원ID : 아이디", required = true) @RequestParam String id,
            @ApiParam(value = "비밀번호", required = true) @RequestParam String password) {

        Employee employee = employeeJpaRepository.findById(id).orElseThrow(CEmailSigninFailedException::new);
        if (!passwordEncoder.matches(password, employee.getPassword()))
            throw new CEmailSigninFailedException();

        return responseService
                .getResult_Single(jwtTokenProvider.createToken(String.valueOf(employee.getNo()), employee.getRoles()));
    }

    /**
     * Hibernate: insert into "employee" ( insert_timestamp, is_deleted,
     * updated_timestamp
     * 
     * @param id
     * @param password
     * @param name
     * @param groupName
     * @param mail
     * @param employeeContact
     * @return
     */
    @ApiOperation(value = "가입", notes = "회원가입을 한다.")
    @PostMapping(value = "/signup")
    public Common signup(@ApiParam(value = "회원ID : 아이디", required = true) @RequestParam String id,
            @ApiParam(value = "비밀번호", required = true) @RequestParam String password,
            @ApiParam(value = "이름", required = true) @RequestParam String name,
            @ApiParam(value = "조직 이름", required = true) @RequestParam String groupName,
            @ApiParam(value = "회사 전화번호", required = true) @RequestParam String mail,
            @ApiParam(value = "메일", required = true) @RequestParam String employeeContact) {
        employeeJpaRepository.save(Employee.builder().id(id).password(passwordEncoder.encode(password)).name(name)
                .groupName(groupName).mail(mail).employeeContact(employeeContact).insertTimestamp(new Date())
                .updatedTimestamp(null).isDeleted("f").roles(Collections.singletonList("ROLE_USER")).build());
        return responseService.getResultSuccess();
    }
}