package com.rest.api.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.Getter;
import lombok.Setter;

/**
 * ApiController
 */
@Controller
public class ApiController {
    private static final String API_MONITOR = "this web page is Api monitoring!";

    @Setter
    @Getter
    public static class ApiMonitor {
        private String message;
    }

    @GetMapping(value = "/apiMonitor/string")
    @ResponseBody
    public String ApiMonitorString() {
        return API_MONITOR;
    }

    @GetMapping(value = "/apiMonitor/json")
    @ResponseBody
    public ApiMonitor ApiMonitorJson() {
        ApiMonitor apiMonitor = new ApiMonitor();
        apiMonitor.message = API_MONITOR;
        return apiMonitor;
    }

    @GetMapping(value = "/apiMonitor/page")
    public String apiMonitor() {
        return API_MONITOR;
    }
}