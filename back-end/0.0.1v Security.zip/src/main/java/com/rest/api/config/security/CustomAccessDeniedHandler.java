package com.rest.api.config.security;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

/**
 * CustomAccessDeniedHandler
 * 
 * NOTE
 * ### AccessDeniedHandler ### 
 * - 인증(로그인)은 되었으나 해당 요청에 대한 권한이 없을 경우에는
 * AccessDeniedHandler 부분에서 AccessDeniedException 이 발생된다.
 * 
 * NOTE
 * ### RequestDispatcher ###
 * - 클라이언트로부터 최초에 들어온 요청을 JSP/Servlet 내에서 원하는 자원으로 요청을 넘기는(보내는) 역할을 수행하
 * - 특정 자원에 처리를 요청하고 처리 결과를 얻어오는 기능을 수행하는 클래스
 */
@Slf4j
@Component
public class CustomAccessDeniedHandler implements AccessDeniedHandler {
    @Override
    public void handle(HttpServletRequest request, HttpServletResponse response,
            AccessDeniedException accessDeniedException) throws IOException, ServletException {
        RequestDispatcher requestDispatcher = request.getRequestDispatcher("/exception/accessdenied");
        requestDispatcher.forward(request, response);

    }

}