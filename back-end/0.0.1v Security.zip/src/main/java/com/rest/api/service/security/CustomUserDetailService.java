package com.rest.api.service.security;

import com.rest.api.advice.exception.CEmployeeNotFoundException;
import com.rest.api.repo.EmployeeJpaRepository;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;


/**
 * CustomUserDetailService
 */
@RequiredArgsConstructor
@Service
public class CustomUserDetailService implements UserDetailsService {

    private final EmployeeJpaRepository employeeJpaRepository;
    
    //Employee
    public UserDetails loadUserByUsername(String no) {
        return employeeJpaRepository.findById(Long.valueOf(no)).orElseThrow(CEmployeeNotFoundException::new);
    }
}
