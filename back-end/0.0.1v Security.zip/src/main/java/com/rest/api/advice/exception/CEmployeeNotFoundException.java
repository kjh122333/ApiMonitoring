package com.rest.api.advice.exception;

/**
 * CEmployeeNotFoundException
 */
public class CEmployeeNotFoundException extends RuntimeException {

    public CEmployeeNotFoundException(String message, Throwable t) {
        super(message, t);
    }

    public CEmployeeNotFoundException(String message) {
        super(message);
    }

    public CEmployeeNotFoundException() {
        super();
    }
}