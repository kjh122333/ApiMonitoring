package com.rest.api.service;

import java.util.List;

import com.rest.api.model.response.result.Common;
import com.rest.api.model.response.result._List;
import com.rest.api.model.response.result._Single;

import org.springframework.stereotype.Service;

/**
 * ResponseService : API 요청 결과에 대한 코드, 메세지를 설정
 */
@Service
public class ResponseService {

    // enum 형식으로 코드, 메세지 정의
    public enum CommonResponse {

        SUCCESS(0, "성공");

        int code;
        String message;

        CommonResponse(int code, String message) {
            this.code = code;
            this.message = message;
        }

        public int getCode() {
            return code;
        }

        public String getMessage() {
            return message;
        }
    }

    // RESULT : SINGLE
    public <T> _Single<T> getResult_Single(T data) {
        _Single<T> result = new _Single<>();
        result.setData(data);
        setSuccessResult(result);
        return result;
    }

    // RESULT : LIST(multi)
    public <T> _List<T> getResult_List(List<T> list) {
        _List<T> result = new _List<>();
        result.setList(list);
        setSuccessResult(result);
        return result;
    }

    // RESULT : COMMON(=SUCCESS)
    public Common getResultSuccess() {
        Common result = new Common();
        setSuccessResult(result);
        return result;
    }

    // RESULT : COMMON(=FAIL)
    public Common getResultFail(int code, String message) {
        Common result = new Common();
        result.setSuccess(false);
        result.setCode(code);
        result.setMessage(message);
        return result;
    }

    // SETTING : API's request Data
    private void setSuccessResult(Common result) {
        result.setSuccess(true);
        result.setCode(CommonResponse.SUCCESS.getCode());
        result.setMessage(CommonResponse.SUCCESS.getMessage());
    }

}