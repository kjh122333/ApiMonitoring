package com.rest.api.config.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.CorsUtils;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import lombok.RequiredArgsConstructor;

/**
 * SecurityConfiguration
 * 
 * @RequiredArgsConstructor
 * @Configuration
 * [CLASS] WebSecurityConfigurerAdapter
 * [INTERFACE] AuthenticationManager
 * 
 */
@RequiredArgsConstructor
@Configuration
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

    private final JwtTokenProvider jwtTokenProvider;

    @Bean
    @Override
    public AuthenticationManager authenticationManager() throws Exception {
        return super.authenticationManager();
    }
    
    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {
        
        httpSecurity
        /**
         * [method] httpBasic() : 비인증시 로그인 폼 화면으로 리다이렉
         * [method] disable() : 해당 메소드 사용 X
         * [method] csrf() : csrf 보안 메소드
         * CSRF : Cross Site Request Forgery, 공격자의 행위 특정 웹사이트에 요청하게 만드는 공격
         * [method] sessionManagement() : 세션 관련
         * [method] sessionCreationPolicy() : 세션 상태 설정
         *                                    STATELESS - 완전 해제
         *                                    NEVER - 내부적으로 세션을 만드는것을 허용
         *                                     ...
         */
                    .httpBasic().disable() // 기본설정 사용X
                    .csrf().disable() // csrf 보안 해제
                    .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS) // 세션 해제 (Jwt토큰으로 인증)
                    
                    .and()  // 페이지별 접근 세팅
                        .authorizeRequests()    // 해당 권한에 부여한 리퀘스트 세팅
                            .requestMatchers(CorsUtils::isPreFlightRequest).permitAll()
                            .antMatchers("/*/signin", "/*/signup").permitAll() // signin, signup은 모두에게 허용
                            .antMatchers(HttpMethod.GET, "/apiMonitor/**").permitAll() // hellowworld은 모두에게 허용
                             .antMatchers("/*/employees").hasRole("ADMIN")   // ADMIN만 유저 목록 가능
                        .anyRequest().hasRole("USER") // 나머지 page는 해당되는 인증된 회원만 접근
                        
                    .and()
                        .exceptionHandling().accessDeniedHandler(new CustomAccessDeniedHandler())
                    .and()
                        .exceptionHandling().authenticationEntryPoint(new CustomAuthenticationEntryPoint())
                    .and()
                        // 필터 순서 : (1)jwt token filter (2)id/password filter
                        .addFilterBefore(new JwtAuthenticationFilter(jwtTokenProvider), UsernamePasswordAuthenticationFilter.class).cors().and(); ;

    }
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        // - (3)
        configuration.addAllowedOrigin("*");
        configuration.addAllowedMethod("*");
        configuration.addAllowedHeader("*");
        configuration.setAllowCredentials(true);
        configuration.setMaxAge(3600L);
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
    /**
     * 스웨거 페이지 세팅
     */
    @Override
    public void configure(WebSecurity web) {
        web.
            ignoring().
            antMatchers (
                            "/v2/api-docs",
                            "/swagger-resources/**", 
                            "/swagger-ui.html", 
                            "/webjars/**", 
                            "/swagger/**"
                        );}
                        
}