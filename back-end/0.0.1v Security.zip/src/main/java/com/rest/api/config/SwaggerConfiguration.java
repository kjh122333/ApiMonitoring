package com.rest.api.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * SwaggerConfiguration
 * 
 * NOTE 
 * 
 * [복습]@Configuration : SpringBean 등록
 * 
 * 1차 미팅 추가 요구사항 : SWAGGER
 * - SWAGGER : REST Api 문서화
 * - @EnableSwagger2 : 해당 어노테이션으로 문서화 설정 가능
 * - [type]Docket : 꼬리표,
 * - select()
 *      - ApiSelectorBuilder 인스턴스를 리턴함
 *      - 하위 설정으로 swagger 세팅
 *      - RequestHandlerSelectors : 설정할 곳 지정
 *      - PathSelectors : 상세 지정
 *      - useDefaultResponseMessages : 기본적인 error 응답 세팅
 * - ApiInfo : 해당 문서에대한 정보에대해 명시해주는 CLASS
 */
@Configuration
@EnableSwagger2
public class SwaggerConfiguration {
    @Bean
    public Docket swaggerApi() {
        return new Docket(DocumentationType.SWAGGER_2).apiInfo(swaggerInfo()).select()
                .apis(RequestHandlerSelectors.basePackage("com.rest.api.controller"))
                .paths(PathSelectors.ant("/employee/**"))
                .build()
                .useDefaultResponseMessages(false); // 기본 세팅(200,401,403,404) 메시지 표시 해제
    }

    private ApiInfo swaggerInfo() {
        return new ApiInfoBuilder().title("[PROJECT]API Monitoring")
                .description("Error API에 대한 등록 및 지속적인 모니터링 웹입니다. ")
                .license("1조").licenseUrl("https://github.com/kjh122333").version("1").build();
            
    }
}