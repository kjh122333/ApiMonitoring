package com.rest.api.advice.exception;

/**
 * CAuthenticationEntryPointException
 * 
 * 사용자 정의 예외처리 (!!! Extend `RuntimeException`)
 * 
 * REVIEW
 * ### exception 폴더 하위 항목들 경고(warn) ###
 * 해당 java 파일이 첫번째라 적어둠...
 * 1. CAuthenticationEntryPointException.java(현재 파일)
 * 2. CEmailSigninFailedException.java
 * 3. CEmployeeNotFoundException.java
 * RuntimeException를 상속 받았는데 해당 클래스 파일 가보면
 * (line44)static final long serialVersionUID = -7034897190745766939L;
 * 정의 되어있다. 
 * 
 * 직렬화 고유 id 선언인데, 권장사항은 개발자가 직적 선언하면되는 것인데, 하고
 * 돌리니깐 에러 터짐... JVM에서 디폴트로 생성해줘서 안해도 상관없음. 밑줄 신경쓰이긴 하는데
 * 일단 무시하고, 건들지말자!
 */
public class CAuthenticationEntryPointException extends RuntimeException {
    public CAuthenticationEntryPointException(String message, Throwable t) {
        super(message, t);
    }

    public CAuthenticationEntryPointException(String message) {
        super(message);
    }

    public CAuthenticationEntryPointException() {
        super();
    }
}