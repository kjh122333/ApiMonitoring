package com.rest.api.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import org.hibernate.annotations.ColumnDefault;

/**
 * Employee
 */
@Builder // builder를 사용
@Entity // JPA Entity 명시
@Getter
@NoArgsConstructor // 인자없는 생성자를 자동으로 생성
@AllArgsConstructor // 인자를 모두 갖춘 생성자를 자동 생성
@Table(name = "\"employee\"") // 'user' 테이블과 매핑을 명시
public class Employee implements UserDetails {
    // user_id character varying(100) NOT NULL, -- 아이디
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long no;
    @Column(nullable = false, unique = true, length = 50)
    private String id;

    // user_password -- 비밀번호, #jwt#인코딩
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Column(nullable = false, length = 100)
    private String password;

    // user_name character varying(100) NOT NULL, -- 이름
    @Column(nullable = false, length = 100)
    private String name;

    // organization_full_path character varying(100) NOT NULL, -- 조직 이름
    @Column(nullable = false, length = 100)
    private String groupName;

    // user_default_email character varying(100), -- 사용자 기본 이메일
    @Column(nullable = false, length = 100)
    private String mail;

    // employee_contact character varying(32), -- 회사 전화번호
    @Column(nullable = false, length = 32)
    private String employeeContact;

    // insert_timestamp timestamp without time zone NOT NULL DEFAULT now(), -- 생성날짜
    @Column(nullable = false, columnDefinition = "TIMESTAMP WITH TIME ZONE")
    @Temporal(TemporalType.TIMESTAMP)
    private java.util.Date insertTimestamp;

    // updated_timestamp timestamp without time zone, -- 수정날짜
    @Column(columnDefinition = "TIMESTAMP WITH TIME ZONE")
    @Temporal(TemporalType.TIMESTAMP)
    private java.util.Date updatedTimestamp;

    // is_deleted character(1) NOT NULL DEFAULT ‘F’::bpchar, -- 삭제여부
    @ColumnDefault(value = "'F'")
    @Column(nullable = false, length = 1)
    private String isDeleted;
    // CONSTRAINT
    // pk_employee PRIMARY KEY (employee_no),

    @ElementCollection(fetch = FetchType.EAGER)
    @Builder.Default
    private List<String> roles = new ArrayList<>();

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return this.roles.stream().map(SimpleGrantedAuthority::new).collect(Collectors.toList());
    }

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Override
    public String getUsername() {
        return this.id;
    }

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Override
    public boolean isEnabled() {
        return true;
    }
}

/*
 * CREATE TABLE employee ( employee_no bigint NOT NULL DEFAULT
 * nextval(‘employee’::regclass), -- 조직-사용자 테이블 시퀀스 user_name character
 * varying(100) NOT NULL, -- 이름 user_id character varying(100) NOT NULL, -- 이름
 * organization_full_path character varying(100) NOT NULL, -- 조직 전체 이름
 * user_default_email character varying(100), -- 사용자 기본 이메일 employee_contact
 * character varying(32), -- 회사 전화번호 insert_timestamp timestamp without time
 * zone NOT NULL DEFAULT now(), -- 생성날짜 updated_timestamp timestamp without time
 * zone, -- 수정날짜 is_deleted character(1) NOT NULL DEFAULT ‘F’::bpchar, -- 삭제여부
 * 
 * CONSTRAINT
 * 
 * pk_employee PRIMARY KEY (employee_no),
 * 
 * ) WITH ( OIDS=FALSE ); CREATE SEQUENCEseq_service INCREMENT 1 MINVALUE 1
 * MAXVALUE 9223372036854775807 START 1 CACHE 1; ALTER TABLE seq_service OWNER
 * TO pgadmin;
 */