package com.rest.api.advice;

import javax.servlet.http.HttpServletRequest;

import com.rest.api.advice.exception.CAuthenticationEntryPointException;
import com.rest.api.advice.exception.CEmailSigninFailedException;
import com.rest.api.advice.exception.CEmployeeNotFoundException;
import com.rest.api.model.response.result.Common;
import com.rest.api.service.ResponseService;

import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import lombok.RequiredArgsConstructor;

/**
 * ExceptionAdvice
 * ------------------------------------------------------------
 * NOTE ### @RequiredArgsConstructor ### 
 * - lombok 
 * - 초기화 되지 않은 `final 필드`와
 * `@NonNull`이 붙은 필드에 대한 생성자 생성
 * ------------------------------------------------------------
 * ### @RestControllerAdvice ### 
 * - 기본적으로 Controller 빈을 도와주는 놈
 * - 공통 예외 처리 핸들링
 * - Spring에서 예외처리(exception)을 전역(Global)으로 핸들링해줌
 * ------------------------------------------------------------
 * ### @ExceptionHandler( xxx.class ) ###
 * - METHOD 레벨단에서 해당 예외처리 담당
 * ------------------------------------------------------------
 * ### @ResponseStatus ###
 * - 예외 발생시, 반환 값(code, message)을 던지기 위해 사용
 */
@RequiredArgsConstructor
@RestControllerAdvice
public class ExceptionAdvice {

    private final ResponseService responseService;
    private final MessageSource messageSource;

    // java.lang.Error
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    protected Common defaultException(HttpServletRequest request, Exception e) {
        // 예외 처리의 메시지를 MessageSource에서 가져오도록 수정
        return responseService.getResultFail(Integer.valueOf(getMessage("unKnown.code")),
                getMessage("unKnown.message"));
    }

    // ~/exception/
    @ExceptionHandler(CEmployeeNotFoundException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    protected Common userNotFound(HttpServletRequest request, CEmployeeNotFoundException e) {
        return responseService.getResultFail(Integer.valueOf(getMessage("userNotFound.code")),
                getMessage("userNotFound.message"));
    }

    // ~/exception/
    @ExceptionHandler(CEmailSigninFailedException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    protected Common emailSigninFailed(HttpServletRequest request, CEmailSigninFailedException e) {
        return responseService.getResultFail(Integer.valueOf(getMessage("emailSigninFailed.code")),
                getMessage("emailSigninFailed.message"));
    }

    // ~/exception/
  @ExceptionHandler(CAuthenticationEntryPointException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public Common authenticationEntryPointException(HttpServletRequest request, CAuthenticationEntryPointException e) {
        return responseService.getResultFail(Integer.valueOf(getMessage("entryPointException.code")), getMessage("entryPointException.message"));
    }

    /**
     * AccessDeniedException : 권한 예외 처리
     */
    // security.access.AccessDeniedException
    @ExceptionHandler(AccessDeniedException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public Common accessDeniedException(HttpServletRequest request, AccessDeniedException e) {
        return responseService.getResultFail(Integer.valueOf(getMessage("accessDenied.code")),
                getMessage("accessDenied.message"));
    }

        // 조회 : 해당 코드에 대한 메시지
    private String getMessage(String code) {
        return getMessage(code, null);
    }

    // 조회 : 코드정보, 추가 argument로 현재 지역(다국어)에 맞는 메시지
    private String getMessage(String code, Object[] args) {
        return messageSource.getMessage(code, args, LocaleContextHolder.getLocale());
    }
}