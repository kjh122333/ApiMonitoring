package com.rest.api.model.response.result;

import lombok.Getter;
import lombok.Setter;

/**
 * _Single
 */
@Getter
@Setter
public class _Single<T> extends Common {
    private T data;
}