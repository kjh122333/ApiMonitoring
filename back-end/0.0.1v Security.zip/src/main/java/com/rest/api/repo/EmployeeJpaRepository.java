package com.rest.api.repo;

import java.util.Optional;

import com.rest.api.entity.Employee;

import org.springframework.data.jpa.repository.JpaRepository;
/**
 * EmployeeJpaRepository
 */
public interface EmployeeJpaRepository extends JpaRepository<Employee, Long> {

    Optional<Employee> findById(String id);
}