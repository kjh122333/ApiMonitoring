package com.rest.api.model.response.result;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * _List
 */
@Getter
@Setter
public class _List <T> extends Common {

    private List<T> list;        
}
