package com.rest.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
/**
 * 임시 주석 : 버킷 푸시를 통한 젠킨스 빌드 후 aws 서버에 배포 테스트 1
 */
@SpringBootTest
class SpringrestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
