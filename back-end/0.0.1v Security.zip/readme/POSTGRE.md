# POSTGRE

## __명령어__

### 접속

```
➜  ~ psql --host=postgresql.c3ov9aiuaeum.ap-northeast-2.rds.amazonaws.com --port=5432 --username=postgres --password
```

### database 목록 조회

```
\list
\l
```

### table 목록 조회

```
\dt
```
